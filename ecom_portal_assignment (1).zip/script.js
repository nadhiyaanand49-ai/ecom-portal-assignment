document.getElementById("registerForm").addEventListener("submit", function(e){
  e.preventDefault();
  alert("Registration validation successful!");
});

document.getElementById("loginForm").addEventListener("submit", function(e){
  e.preventDefault();
  alert("Login validation successful!");
});